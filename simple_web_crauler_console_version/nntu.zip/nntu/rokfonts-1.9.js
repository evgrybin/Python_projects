/**
 * rokSifr - A multicolor-sifr helper that let the first word be colored.
 * 
 * @version		1.9
 * 
 * @license		MIT-style license
 * @author		Djamil Legato <djamil [at] djamil.it>
 * @client		Andy Miller @ Rockettheme
 * @copyright	Author
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('2 m=3(g,j,k){(g.8).n(3(i){2 e="."+g[i];2 f=3(a){a.o(\'p\',\'q\');2 b=a.r(\'4\');2 c=b.s(" ");9=c[0];5=c.t(1).u(" ");v=a.w;x(5.8>0){2 d=a.y().l(\'4\',\' \'+5),6=z A(\'6\').l(\'4\',9);6.B(d,\'C\');d.D(a)}};$$(e).7(3(b){j.7(3(h){b.E(h).7(3(a){f(a)})})})})};',41,41,'||var|function|text|rest|span|each|length|first||||||||||||set|RokBuildSpans|times|setStyle|visibility|visible|get|split|slice|join|html|innerHTML|if|clone|new|Element|inject|top|replaces|getElements'.split('|'),0,{}))